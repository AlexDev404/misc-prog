const express = require("express");
const mongoose = require("mongoose");
const Article = require("./models/article");
const methodOverride = require("method-override");
const app = express();

mongoose.connect("mongodb://localhost", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true,
});
const connection = mongoose.connection;

connection.once("open", function () {
  app.use(express.urlencoded({ extended: false }));
  app.use(methodOverride("_action"));
  const articleRouter = require("./routes/articles");
  app.use(express.static(__dirname + "/public"));

  app.set("view engine", "ejs");

  app.get("/", async (req, res) => {
    const articles = await Article.find().sort({ createdAt: "desc" });
    res.render("./articles/index", { articles: articles });
  });
  app.use("/articles", articleRouter);
  app.listen(5000);
});
